public interface Married {

    final boolean isMarried = true;

    void getMarried(Person p);

    void getDivorced();

    void setRing(String ringName);
}