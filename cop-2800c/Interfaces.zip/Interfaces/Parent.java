public interface Parent {

    final boolean isParent = true;

    Person haveChild();
}