public interface Student {

    final boolean isStudent = true;

    void doHomwork();

    void graduateHighSchool();

    void startCollege();

    void graduateCollege();

}
